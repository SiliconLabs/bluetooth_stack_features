from setuptools import setup

setup(
    name = 'bgapi_trace',
    version = '0.6.2',
    packages = ['bgapi_trace'],
    install_requires = ['pybgapi>=1.2.0', 'pylink-square>=1.2.0'],
    entry_points = {
        'console_scripts': [
            'bgapi_trace = bgapi_trace.bgapi_trace:main',
        ],
    }
)
